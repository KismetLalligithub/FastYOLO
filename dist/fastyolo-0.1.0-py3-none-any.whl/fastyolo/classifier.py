from fastai.vision.all import load_learner

def load_classifier(path):
    return load_learner(path)
